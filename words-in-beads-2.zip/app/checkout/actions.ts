"use server"

import { EUR_TO_BGN } from "@/lib/site-data"

export type OrderItemInput = {
  title: string
  variantName: string
  personalization?: string
  priceEur: number
  quantity: number
}

export type OrderInput = {
  firstName: string
  lastName: string
  phone: string
  email: string
  courier: string
  address: string
  note?: string
  items: OrderItemInput[]
}

export type OrderResult =
  | { ok: true; orderNumber: string; totalEur: number; totalBgn: number }
  | { ok: false; error: string }

function isEmail(value: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)
}

export async function placeOrder(order: OrderInput): Promise<OrderResult> {
  const firstName = order.firstName?.trim()
  const lastName = order.lastName?.trim()
  const phone = order.phone?.trim()
  const email = order.email?.trim()
  const courier = order.courier?.trim()
  const address = order.address?.trim()

  if (!firstName || !lastName) {
    return { ok: false, error: "Моля, попълнете двете имена." }
  }
  if (!phone || phone.replace(/\D/g, "").length < 6) {
    return { ok: false, error: "Моля, въведете валиден телефон за връзка." }
  }
  if (!email || !isEmail(email)) {
    return { ok: false, error: "Моля, въведете валиден имейл адрес." }
  }
  if (!courier) {
    return { ok: false, error: "Моля, изберете куриерска фирма." }
  }
  if (!address) {
    return { ok: false, error: "Моля, въведете адрес или офис за доставка." }
  }
  if (!order.items?.length) {
    return { ok: false, error: "Количката е празна." }
  }

  const totalEur = order.items.reduce(
    (sum, i) => sum + i.priceEur * i.quantity,
    0,
  )
  const totalBgn = Number((totalEur * EUR_TO_BGN).toFixed(2))
  const orderNumber = `WIB-${Date.now().toString(36).toUpperCase().slice(-6)}`

  // Записваме детайлите на поръчката (в реална среда тук се изпраща имейл/съобщение).
  console.log("[v0] Нова поръчка", {
    orderNumber,
    customer: { firstName, lastName, phone, email },
    delivery: { courier, address, note: order.note?.trim() || null },
    items: order.items,
    totalEur,
    totalBgn,
  })

  return { ok: true, orderNumber, totalEur, totalBgn }
}
